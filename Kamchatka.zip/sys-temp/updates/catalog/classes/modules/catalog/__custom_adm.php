<?php
	abstract class __custom_adm_catalog {
		//TODO: Write here your own macroses (admin mode)
	};
?>