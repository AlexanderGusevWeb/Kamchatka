<?php
	/** Класс пользовательских методов административной панели */
	class CatalogCustomAdmin {
		/** @var catalog $module */
		public $module;

	}
