<?php
	/** Класс пользовательских методов административной панели */
	class CatalogCustomMacros {
		/** @var catalog $module */
		public $module;

	}
