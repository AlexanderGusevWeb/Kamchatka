<?php
	$permissions = Array(
		'service' => Array('updateall'),
		'versions' => Array('updatemodule', 'getSupportEndDate')
	);
?>