<?php
	echo <<<JS
window.location = "/smu/index.php";

JS;
	exit();
?>