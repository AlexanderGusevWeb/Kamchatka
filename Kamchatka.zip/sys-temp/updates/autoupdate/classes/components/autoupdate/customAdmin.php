<?php
	/** Класс пользовательских методов административной панели */
	class AutoUpdateCustomAdmin {
		/** @var autoupdate $module */
		public $module;
	}
