<?php
	/** Класс пользовательских макросов */
	class AutoUpdateCustomMacros {

		/** @var autoupdate $module */
		public $module;
	}
