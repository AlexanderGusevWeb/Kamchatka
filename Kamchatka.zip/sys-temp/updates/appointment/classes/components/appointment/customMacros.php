<?php
	/** Класс пользовательских макросов */
	class AppointmentCustomMacros {

		/** @var autoupdate $module */
		public $module;
	}
