<?php
	/** Класс пользовательских методов административной панели */
	class AppointmentCustomAdmin {

		/** @var appointment $module */
		public $module;

	}
