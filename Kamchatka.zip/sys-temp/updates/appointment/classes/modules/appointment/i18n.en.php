<?php
	/** Языковые константы для английской версии */
	$i18n = [
		'header-appointment-orders' => 'Appointment orders',
		"module-appointment"	=> "Appointments"
	];
