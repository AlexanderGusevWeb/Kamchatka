<?php
	/** Языковые константы для русской версии */
	$i18n = [
		'header-appointment-orders' => 'Заявки на запись',
		"module-appointment"	=> "Онлайн-запись"
	];
