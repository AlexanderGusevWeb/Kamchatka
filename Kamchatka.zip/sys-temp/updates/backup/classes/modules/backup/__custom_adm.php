<?php
	abstract class __backup_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>