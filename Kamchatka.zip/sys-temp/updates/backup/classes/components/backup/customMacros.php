<?php
	/** Класс пользовательских макросов */
	class BackupCustomMacros {
		/** @var backup $module */
		public $module;
	}
