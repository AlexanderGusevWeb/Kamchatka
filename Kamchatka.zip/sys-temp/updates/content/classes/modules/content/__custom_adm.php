<?php
	abstract class __content_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>