<?php
/*
*/

class __tagsAccountUsageCloud {
	/*
	*/

	public function tagsAccountUsageCloud($s_template = "tags", $i_per_page = -1, $b_ignore_paging = true) {
		/*
		*/

		return $this->tags_mk_cloud(NULL, $s_template, $i_per_page, $b_ignore_paging, true, array());
	}
}
?>