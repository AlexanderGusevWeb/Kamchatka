<?php
	abstract class __custom_comments {
		//TODO: Write here your own macroses
	};

?>