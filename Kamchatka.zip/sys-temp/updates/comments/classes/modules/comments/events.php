<?php
new umiEventListener('comments_message_post_do', 'comments', 'onCommentPost');
?>
