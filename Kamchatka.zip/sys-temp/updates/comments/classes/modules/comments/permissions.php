<?php
	$permissions = Array(
		'insert' => Array(
			'post',
			'comment',
			'countComments',
			'smilePanel',
			'insertVkontakte',
			'insertFacebook',
		), 
		'view_comments' => Array(
			'del',
			'edit',
			'activity',
			'view_noactive_comments',
			'publish',
			'comment.edit'
		)
	);
?>