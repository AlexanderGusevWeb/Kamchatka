<?php
	/** Класс пользовательских методов административной панели */
	class CommentsCustomAdmin {
		/** @var comments $module */
		public $module;

	}
