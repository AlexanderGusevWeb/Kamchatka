<?php
	/** Класс пользовательских методов административной панели */
	class CommentsCustomMacros {
		/** @var comments $module */
		public $module;

	}
