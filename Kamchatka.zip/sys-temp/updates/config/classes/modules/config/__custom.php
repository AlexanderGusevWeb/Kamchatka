<?php
	abstract class __config_custom {
		
	};
?>
