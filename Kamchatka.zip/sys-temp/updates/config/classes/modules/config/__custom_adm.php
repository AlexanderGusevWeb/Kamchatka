<?php
	abstract class __config_custom_admin {
		//TODO: Write here your own macroses (admin mode)
	};
?>