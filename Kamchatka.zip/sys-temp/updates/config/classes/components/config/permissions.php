<?php
	/** Группы прав на функционал модуля */
	$permissions = [
		/** Права на запуск крона по http */
		'cron_http_execute' => []
	];