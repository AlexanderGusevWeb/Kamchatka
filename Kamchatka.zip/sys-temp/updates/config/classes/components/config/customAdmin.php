<?php
	/** Класс пользовательских методов административной панели */
	class ConfigCustomAdmin {
		/** @var config $module */
		public $module;

	}
