<?php
	/** Класс пользовательских методов административной панели */
	class BannersCustomAdmin {
		/** @var banners $module */
		public $module;
	}
