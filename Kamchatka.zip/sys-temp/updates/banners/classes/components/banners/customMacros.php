<?php
	/** Класс пользовательских макросов */
	class BannersCustomMacros {
		/** @var banners $module */
		public $module;
	}
