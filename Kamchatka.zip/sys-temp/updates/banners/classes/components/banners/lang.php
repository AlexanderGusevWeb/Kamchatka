<?php
	/** Языковые константы для русской версии */
	$C_LANG = [];
	$C_LANG['module_name'] = 'Баннеры';
	$C_LANG['module_title'] = 'Ротация баннеров';
	$C_LANG['module_description'] = <<<END

	Позваляет создавать графические, флешовые, текстовые, и HTML баннеры.
	Поддерживается тайм-таргетинг.

END;
	$C_LANG['places_list'] = 'Расположение';
	$C_LANG['banners_list'] = 'Список баннеров';
	$C_LANG['banner_add'] = 'Добавление баннера';
	$C_LANG['place_add'] = 'Добавление расположения';
	$C_LANG['place_edit'] = 'Редактирование расположения';
	$C_LANG['add_banner'] = 'Добавление баннера';
	$C_LANG['banner_edit'] = 'Редактирование баннера';
	$C_LANG['apply_filters'] = 'Поиск баннера';

	$LANG_EXPORT = [];
	$LANG_EXPORT['banners_cifi_upload_text'] = 'Закачать';

