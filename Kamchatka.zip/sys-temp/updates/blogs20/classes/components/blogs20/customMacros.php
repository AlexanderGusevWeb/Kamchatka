<?php
	/** Класс пользовательских макросов */
	class BlogsCustomMacros {
		/** @var blogs20 $module */
		public $module;
	}
